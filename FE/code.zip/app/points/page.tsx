"use client"

import Points from "@/components/points"

export default function PointsPage() {
  return <Points />
}
