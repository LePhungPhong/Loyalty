"use client"

import Transactions from "@/components/transactions"

export default function TransactionsPage() {
  return <Transactions />
}
