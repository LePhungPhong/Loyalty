"use client"

import Customers from "@/components/customers"

export default function CustomersPage() {
  return <Customers />
}
