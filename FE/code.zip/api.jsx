// This provides the API interface that the dashboard components use

class API {
  static async get(endpoint) {
    // Mock API responses for development
    const mockData = {
      "/customers": [
        { id: 1, name: "Khách hàng 1", email: "customer1@example.com" },
        { id: 2, name: "Khách hàng 2", email: "customer2@example.com" },
        { id: 3, name: "Khách hàng 3", email: "customer3@example.com" },
      ],
      "/points": [
        { id: 1, customerId: 1, points: 1500 },
        { id: 2, customerId: 2, points: 2300 },
        { id: 3, customerId: 3, points: 800 },
      ],
      "/transactions": [
        { id: 1, subtotal: 500000, paidAt: "2024-01-15T10:30:00Z" },
        { id: 2, subtotal: 750000, paidAt: "2024-01-14T14:20:00Z" },
        { id: 3, subtotal: 320000, paidAt: "2024-01-13T09:15:00Z" },
      ],
    }

    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(mockData[endpoint] || [])
      }, 100)
    })
  }

  static async post(endpoint, data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true, data })
      }, 100)
    })
  }

  static async put(endpoint, data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true, data })
      }, 100)
    })
  }

  static async delete(endpoint) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true })
      }, 100)
    })
  }
}

export default API
